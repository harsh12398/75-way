const http = require('http');

const PORT = 3000;

const tests = [
    {
        name: 'Admin access (Charlie) to Sensitive Management Resource',
        headers: { 'x-user-id': 'admin-1' },
        resId: 'res-3',
        expected: 200
    },

    {
        name: 'User (Bob) access to IT Config (Wrong Department)',
        headers: { 'x-user-id': 'user-2' },
        resId: 'res-1',
        expected: 403
    },

    {
        name: 'Invalid user access',
        headers: { 'x-user-id': 'unknown' },
        resId: 'res-1',
        expected: 401
    }
];

async function runTests() {
    console.log('--- Starting ABAC Verification ---\n');

    for (const test of tests) {
        process.stdout.write(`Testing: ${test.name}... `);
        try {
            await new Promise((resolve, reject) => {
                const req = http.request(
                    {
                        hostname: 'localhost',
                        port: PORT,
                        path: `/resources/${test.resId}`,
                        method: 'GET',
                        headers: test.headers
                    },
                    (res) => {
                        if (res.statusCode === test.expected) {
                            console.log(' PASSED');
                        } else {
                            console.error(` FAILED (Expected ${test.expected}, got ${res.statusCode})`);
                        }
                        resolve();
                    }
                );
                req.on('error', reject);
                req.end();
            });
        } catch (err) {
            console.error(` ERROR: ${err.message}`);
        }
    }
    console.log('\n--- Verification Finished ---');
    process.exit(0);
}


const healthCheck = http.get(`http://localhost:${PORT}/resources`, (res) => {
    runTests();
}).on('error', () => {
    console.error('Error: Server is not running. Please run "node server.js" first.');
    process.exit(1);
});
