const express = require('express');
const app = express();
app.use(express.json());

const users = {
    'user-1': { id: 'user-1', name: 'Alice', role: 'user', department: 'IT', clearance: 2 },
    'admin-1': { id: 'admin-1', name: 'Charlie', role: 'admin', department: 'Management', clearance: 3 }
};


const resources = [
    { id: 'res-1', name: 'IT Server Config', department: 'IT', minClearance: 2, ownerId: 'user-1' },
    { id: 'res-3', name: 'Global Strategy', department: 'Management', minClearance: 3, ownerId: 'admin-1' }
];


const authenticate = (req, res, next) => {
    const userId = req.headers['x-user-id'];
    const user = users[userId];
    if (!user) {
        return res.status(401).json({ error: 'Unauthorized: No valid user identified' });
    }
    req.user = user;
    next();
};
const authorizeABAC = (action) => {
    return (req, res, next) => {
        const user = req.user;

        const resourceId = req.params.id;
        const resource = resources.find(r => r.id === resourceId);

        if (!resource) {
            return res.status(404).json({ error: 'Resource not found' });
        } -
            let permit = false;
        if (user.role === 'admin') {
            permit = true;
        }
        else if (resource.ownerId === user.id) {
            permit = true;
        }
        else if (user.department === resource.department && user.clearance >= resource.minClearance) {
            permit = true;
        }

        if (permit) {
            console.log(`[ABAC] PERMIT: User ${user.name} (${user.role}) granted access to ${resource.name}`);
            req.resource = resource;
            next();
        } else {
            console.log(`[ABAC] DENY: User ${user.name} (${user.role}) denied access to ${resource.name}`);
            res.status(403).json({
                error: 'Forbidden: You do not have the required attributes to access this resource',
                details: {
                    userAttributes: { department: user.department, clearance: user.clearance },
                    resourceAttributes: { department: resource.department, minClearance: resource.minClearance }
                }
            });
        }
    };
};

app.get('/resources', authenticate, (req, res) => {
    res.json(resources.map(r => ({ id: r.id, name: r.name })));
});
app.get('/resources/:id', authenticate, authorizeABAC('read'), (req, res) => {
    res.json({
        message: 'Access Granted',
        resource: req.resource
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`ABAC Server running on http://localhost:${PORT}`);
    console.log('Try headers like: "x-user-id: user-1" or "x-user-id: user-2"');
});